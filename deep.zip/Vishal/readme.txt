To use this website 
Open terminal
y
In spartans (project directory ) directory run   

     
nodemon server.js

And go to http://localhost:4000/

This is a responsive website so you can change to iPhone 12 also on chrome developer tools

If you don't have some of tools then install it 
Install Nodejs and rpm
Run
Npm init
npm install mongoose
npm install express
npm install ejs
npm install cheerio
npm install body-parser
npm install async

If database not print in event remove, comment remove line as it is removing the data loading we added it for convince you can remove it and check

MongoDB
vishalmeena2486@gmail.com
Vishal123 //password


Group name Spartans 
Vishal Meena 200101110
Deep Kaur 200101028
Vanshita 200101103
Shashank 200101092
Mihir sagar 200101065












